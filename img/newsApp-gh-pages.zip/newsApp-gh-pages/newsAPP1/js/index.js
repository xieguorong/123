$(function(){
	 var swiperV = new Swiper('.swiper-container-v', {           
       direction: 'vertical', 
       freeMode : true,
   });  
   var swiperH = new Swiper('.swiper-container-h', { 
   		freeMode : true,
       noSwiping : true,
       spaceBetween: 20    
   });  
   var swiperC = new Swiper('.swiper-container-comments', {  
       freeMode : true,
       spaceBetween: 10 
   });
   
   function resize(originSize,type){
		var type=type || "x"
		var widths=$(window).width();
		var heights=$(window).height();
		if(type=="x"){
			$("html").css("font-size",widths/originSize*100+"px")
		}else if(type=="y"){
			$("html").css("font-size",heights/originSize*100+"px")
		}
	}
   resize(750,"x")
})